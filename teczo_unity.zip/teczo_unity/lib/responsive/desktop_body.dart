import 'package:flutter/cupertino.dart';
import 'package:flutter/material.dart';

import '../commmon widget/navigartion_bar_with_start.dart';
import '../commmon widget/navigation_bar.dart';

class MyDesktopBody extends StatelessWidget {
  const MyDesktopBody({Key? key}) : super(key: key);

  @override
  Widget build(BuildContext context) {
    return Scaffold(
      backgroundColor: Colors.white,
      body: Column(
        mainAxisAlignment: MainAxisAlignment.start,
        mainAxisSize: MainAxisSize.min,
        children: [
          //topbar
          Container(
            height: 50.0,
            decoration: BoxDecoration(
              border: Border(
                bottom: BorderSide(
                  color: Color.fromARGB(255, 235, 235, 235),
                  width: 1.0,
                ),
              ),
            ),
            child: Row(
              children: [
                Expanded(child: Row(
                  children: [
                    Icon(Icons.build),
                    Text('Build'),
                  ],
                ),),
                Expanded(child: Text('Sample Project - Seaport Civic Center'),),
                Expanded(child: Text('21 days remaining on 2 of yourtrials'),),
                Expanded(child: Text('View Buying Options'),),
                Expanded(child: Text('Techzo Unity'),),
              ],
            ),
          ),

          //body
          Expanded(
            child: Row(
              children: [
                Expanded(
                  flex: 1,
                  child: ListView(
                    children: <Widget>[
                      NavigationBarLeft(
                          color: Colors.white, icon: Icons.home, title: 'Home'),
                      NavigationBarLeftWithStar(
                          color: Color.fromARGB(255, 245, 245, 245),
                          icon: Icons.description,
                          title: 'Sheets'),
                      NavigationBarLeftWithStar(
                          color: Color.fromARGB(255, 245, 245, 245),
                          icon: Icons.description,
                          title: 'Sheets'),
                      NavigationBarLeft(
                          color: Color.fromARGB(255, 245, 245, 245),
                          icon: Icons.description,
                          title: 'Sheets'),
                      NavigationBarLeft(
                          color: Color.fromARGB(255, 245, 245, 245),
                          icon: Icons.description,
                          title: 'Sheets'),
                      NavigationBarLeft(
                          color: Color.fromARGB(255, 245, 245, 245),
                          icon: Icons.description,
                          title: 'Sheets'),
                      NavigationBarLeft(
                          color: Color.fromARGB(255, 245, 245, 245),
                          icon: Icons.description,
                          title: 'Sheets'),
                      NavigationBarLeft(
                          color: Color.fromARGB(255, 245, 245, 245),
                          icon: Icons.description,
                          title: 'Sheets'),
                      NavigationBarLeft(
                          color: Color.fromARGB(255, 245, 245, 245),
                          icon: Icons.description,
                          title: 'Sheets'),
                      NavigationBarLeft(
                          color: Color.fromARGB(255, 245, 245, 245),
                          icon: Icons.description,
                          title: 'Sheets'),
                      NavigationBarLeft(
                          color: Color.fromARGB(255, 245, 245, 245),
                          icon: Icons.description,
                          title: 'Sheets'),
                    ],
                  ),
                ),
                Expanded(
                  flex: 6,
                  child: Row(
                    children: [
                      Image.asset('lib/images/image1.svg')
                    ],
                  ),
                ),
                
              ],
            ),
          ),
        ],
      ),
    );
  }
}
