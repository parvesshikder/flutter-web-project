package com.example.teczo_unity

import io.flutter.embedding.android.FlutterActivity

class MainActivity: FlutterActivity() {
}
